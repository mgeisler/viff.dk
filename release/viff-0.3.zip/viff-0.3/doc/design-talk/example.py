import sys
from viff.field import GF
from viff.config import load_config
from viff.runtime import Runtime
from viff.util import dprint

Z31 = GF(31)
my_id, conf = load_config(sys.argv[1])
my_input = Z31(int(sys.argv[2]))

rt = Runtime(conf, my_id, 1)
x, y, z = rt.shamir_share(my_input)
result = (x + y) * z

opened_result = rt.open(result)
dprint("Result: %s", opened_result)
rt.wait_for(opened_result)
